A Pen created at CodePen.io. You can find this one at https://codepen.io/ulaladungdung/pen/YLNPyr.

 I've been sitting on this one for a while. I wanted to try and recreate one of those flashy TV adverts that iterate through text using different effects.

`Greensock` seemed like the natural choice and an opportunity to learn some more from using it.

Accompanying music is opt-in 

Music: All That - Bensound.com

Enjoy!